jQuery( document ).ready( function( $ ) {
	$( 'input.alpha-color-picker' ).alphaColorPicker();
});