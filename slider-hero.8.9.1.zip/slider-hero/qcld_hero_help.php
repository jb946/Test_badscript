<?php 
if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit
?>
<?php
	function  qcld_sliderhero_help() {
		?>
		<div class="wrap">
		
			<div id="poststuff">
			
				<div id="post-body" class="metabox-holder columns-2">
				
					<div id="post-body-content" style="position: relative;">
				

						

						
						<div class="clear">
						<u>
							<h1>Help</h1>
						</u>
						</div>

						<div>
							<h3>General Settings</h3>
					

							<p>
								<strong><u>Custom:</u></strong>
								<br>
									This option will allow you to provide custom width and height for your slider.
								<br>
								<br>
								<strong><u>Full Width:</u></strong>
								<br>
								Provide a custom height in px for your slider. Width will be automatically calculated depending on your screen size.
								<br>
								<br>
								<strong><u>Full Screen:</u></strong>
								<br>
								
								No need to provide any width & height. It will automatically fit any screen size and auto-calculate necessary width and height.
								<br>
								<br>
								<strong><u>Auto:</u></strong>
								<br>
								
								Slider size will fit according to container width. You can define custom height.
							</p>
							
						</div>

						<div style="padding: 15px 10px; border: 1px solid #ccc; text-align: center; margin-top: 20px;">
							 Crafted By: <a href="http://www.quantumcloud.com" target="_blank">Web Design Company</a> - QuantumCloud 
						</div>
						
					  </div>
					  <!-- /post-body-content -->	
					  

						
					</div>
					<!-- /post-body-->	
				
				</div>
				<!-- /poststuff -->
			
			</div>
			<!-- /wrap -->
			
		<?php
	}


